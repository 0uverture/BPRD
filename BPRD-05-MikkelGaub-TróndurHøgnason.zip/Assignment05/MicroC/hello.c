void main(int n) 
{
	for (int i = 0; i < n; i+1)
	{
		print n;
	}
	println;
}