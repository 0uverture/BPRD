﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assingment1
{
    abstract class Binop : Expr
    {
        public Expr E1;
        public Expr E2;
    }
}
