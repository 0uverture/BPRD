void main(){
	int t;
	t = (0 ? 3 : 5);
	print t;
	t = (1 ? 3 : 5);
	print t;
}

