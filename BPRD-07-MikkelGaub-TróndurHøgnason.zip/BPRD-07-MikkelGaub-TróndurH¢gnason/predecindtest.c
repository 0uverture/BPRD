void main(){
	int i;
	i = 0;
	++i;
	++i;
	print i;
	--i;
	print i;
	--i;
	print i;

}

