void main() {
	int i;
	i = 0;
	switch (i) 
	{
	}
}
